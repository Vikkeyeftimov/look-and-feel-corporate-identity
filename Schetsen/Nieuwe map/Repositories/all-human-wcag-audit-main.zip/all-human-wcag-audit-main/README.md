> _Fork_ deze deeltaak en ga aan de slag. De instructie vind je in: [docs/INSTRUCTIONS.md](https://github.com/fdnd-task/all-human-wcag-audit/blob/main/docs/INSTRUCTIONS.md)

# WCAG Audit 

Doe een WCAG test op een bestaande website en rapporteer daarover.

## Titel Website

Welke website heb je getest? Beschrijf de website en upload een screenshot. 

Toon een screenshot van het Lighthouse Accessibility testresultaat.

Schrijf een samenvatting van de testbevindingen.

## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
